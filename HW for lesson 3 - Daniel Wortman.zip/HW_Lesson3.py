
# Assignment #1+2:
try:
    a = 1 / 0
    print("The answer is :", a)
except:
    print("Cannot divide by zero")

# Assignment #3:
# The code is legal but there is only a "try" block and regardless of its success the "finally" block will be performed.

# Assignment #4:
# Except can handel all exceptions to a "try" block.

# Assignment #5:
# The exception handler above is general type of exception without testing particular exception.

# Assignment #6:
# except IOError: handle with wrong files, writing, or reading from files.
# except ZeroDivisionError handle zero value division.

# Assignment #7-10:
with open("words.txt" ,"a+", encoding="utf-8") as my_word:
    my_word.write("Daniel\n")

    my_input = input("Write Hebrew content: ")
    my_word.write(my_input + "\n")

with open("words.txt", "r", encoding="utf-8") as my_words:
    content = my_words.read().splitlines()
    for line in content:
        print(line)
